import { useState } from "react";

function FormComponent({ onSubmit }) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    city: "",
    college: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form); // send data to parent (App.jsx)
    setForm({ name: "", email: "", phone: "", city: "", college: "" }); // clear form
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        name="name"
        placeholder="Enter Name"
        value={form.name}
        onChange={handleChange}
      /><br /><br />
      <input
        type="email"
        name="email"
        placeholder="Enter Email"
        value={form.email}
        onChange={handleChange}
      /><br /><br />
      <input
        type="text"
        name="phone"
        placeholder="Enter Phone"
        value={form.phone}
        onChange={handleChange}
      /><br /><br />
      <input
        type="text"
        name="city"
        placeholder="Enter City"
        value={form.city}
        onChange={handleChange}
      /><br /><br />
      <input
        type="text"
        name="college"
        placeholder="Enter College"
        value={form.college}
        onChange={handleChange}
      /><br /><br />

      <button type="submit">Submit</button>
    </form>
  );
}

export default FormComponent;
