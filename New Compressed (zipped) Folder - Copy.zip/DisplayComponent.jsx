function DisplayComponent({ data }) {
  if (!data) {
    return <h3>No Data Submitted Yet</h3>;
  }

  return (
    <div>
      <h2>📄 Submitted Data</h2>
      <p><b>Name:</b> {data.name}</p>
      <p><b>Email:</b> {data.email}</p>
      <p><b>Phone:</b> {data.phone}</p>
      <p><b>City:</b> {data.city}</p>
      <p><b>College:</b> {data.college}</p>
    </div>
  );
}

export default DisplayComponent;
