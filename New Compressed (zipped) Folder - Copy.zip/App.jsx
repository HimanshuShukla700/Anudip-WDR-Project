import { useState } from "react";
import FormComponent from "./FormComponent";
import DisplayComponent from "./DisplayComponent";

function App() {
  const [formData, setFormData] = useState(null);

  const handleFormSubmit = (data) => {
    setFormData(data); // data from FormComponent
  };

  return (
    <div style={{ textAlign: "center", marginTop: "30px" }}>
      <h1>React Data Transfer Between Components</h1>

      <FormComponent onSubmit={handleFormSubmit} />
      <hr />
      <DisplayComponent data={formData} />
    </div>
  );
}

export default App;
